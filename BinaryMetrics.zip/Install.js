var dir = vv.CurrentScriptPath.substr(0, vv.CurrentScriptPath.lastIndexOf("\\") + 1);
vv.InstallPlugin("Binary Metrics", dir +"BinaryPatternMetrics.dll", true);
