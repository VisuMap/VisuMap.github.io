vv.RemovePlugin("Data Cleansing");
vv.GuiManager.RemoveCustomMenu("Filter/");

vv.SetProperty("DataCleansing.Logicle.Settings", null);