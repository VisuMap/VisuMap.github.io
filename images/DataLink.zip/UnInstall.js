vv.RemovePlugin("Data Link");
vv.SetProperty("DataLink.CmdPort", null);
vv.SetProperty("DataLink.PythonEditor", null);
