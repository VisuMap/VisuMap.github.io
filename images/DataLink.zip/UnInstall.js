vv.RemovePlugin("Data Link");
vv.SetProperty("DataLink.CmdPort", null);