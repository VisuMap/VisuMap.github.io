//
// SaveSortedHeatmap.js
// Save a sorted heatmap into the current Atlas as a label item.
// --------------------------------------------------------------
// 
vv.Import("AtlasHelp.js");
SaveSortedTable();

