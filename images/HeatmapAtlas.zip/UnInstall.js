vv.GuiManager.RemoveCustomMenu("Atlas/");
vv.GuiManager.RemoveCustomButton("Atlas/");
