vv.RemovePlugin("Clip Recorder");
vv.RemoveGlyphSet("VectorField");
