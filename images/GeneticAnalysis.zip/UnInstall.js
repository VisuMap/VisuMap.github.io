vv.RemovePlugin("Genetic Analysis");
vv.GuiManager.RemoveCustomMenu("Blast/");
vv.GuiManager.RemoveCustomMenu("SeqUtil/");
vv.SetProperty("GeneticAnalysis.SmithWaterman", null);
vv.SetProperty("GeneticAnalysis.NeedlemanWunsch", null);