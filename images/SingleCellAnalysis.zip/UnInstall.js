vv.SetProperty("SingleCell.LinkBias", null);
vv.RemovePlugin("Single Cell Analysis");
vv.GuiManager.RemoveCustomMenu("SC-Utilities/");
vv.GuiManager.RemoveCustomMenu("Morph Maps");
vv.GuiManager.RemoveCustomMenu("Tracing Features");
