#=========================================================================
# Model generator for classification and regression.
#=========================================================================
from ModelUtil import *

netCfg = [500, 200, 100, 50]
cBias = 0.1

co = CmdOptions()
ds = ModelDataset('+', 'ClrShp')
md = ModelBuilder(ds.xDim, ds.yDim, co.job)

md.r0 = 0.001

md.AddCNN(winSize=25,stepSize=5,filters=1, activation=tf.nn.sigmoid)
md.AddDropout()
md.AddLayers(netCfg)

with tf.name_scope('Output'):
    md.AddLayers(ds.yDim, None)
    md.AddFilter2(tf.nn.sigmoid, 0, ds.mapDim)

with tf.name_scope('Cost'):
    md.cost = md.MixedCost(md.Output(), md.Label(), ds.mapDim, cBias)

co.Train(md, ds)
