#=========================================================================
# Multi-lane feedforward model
#=========================================================================

from ModelUtil import *

co = CmdOptions()
ds = ModelDataset('+', 'Shp')
md = ModelBuilder(ds.xDim, ds.yDim, co.job)

md.r0 = 0.00025
netCfg =  [ 
    [500,400,300, 200, 100, 50], 
    [300, 200, 100, 50], 
    [100,  500, 100], 
    ]

md.AddLayers(300, tf.nn.sigmoid)
md.AddLanes(netCfg, tf.nn.sigmoid)
md.AddLayers(ds.yDim, tf.nn.sigmoid)

#=========================================================================

md.cost = tf.reduce_sum( tf.square(md.Label() - md.Output())) 
co.Train(md, ds)
if co.logLevel > 2:
    md.ShowGraph()
