#=========================================================================
# Keras.ev.py
#=========================================================================
import sys,os
os.environ['TF_CPP_MIN_LOG_LEVEL']='3'
import tensorflow as tf
import numpy as np
from tensorflow import keras
from tensorflow.python.keras.models import load_model
from ModelUtil import *

#Direction GetTestData

modelName = sys.argv[1]
md = load_model(modelName + '.h5')

test_data = np.genfromtxt('testData.csv', delimiter='|', dtype=np.float32)
output = md.predict(test_data)
np.savetxt("predData.csv", output, delimiter='|', fmt='%.6f')

log = Logger()
log.AppMapping()
