#=========================================================================
# Model generator for regression.
#=========================================================================
from ModelUtil import *

#=========================================================================

co = CmdOptions()
ds = ModelDataset('+', 'Shp')
md = ModelBuilder(ds.xDim, ds.yDim)

netCfg = [200, 100, 50, 40, 30, 20, ds.yDim]
md.r0 = 0.001

md.AddLayers(netCfg, activation=tf.nn.sigmoid, addBias=True)
md.cost = md.SquaredCost( md.Output(), md.Label()) 
md.SetAdamOptimizer(co.epochs, ds.N)

def VariableStates(VarList):
        stateVector = []
        for var in VarList:
            values = var.eval(session=md.sess)
            stateVector.extend( np.reshape(values, values.size) )
        return  stateVector

#========================================
# epCall tor monitor the bias changes
#========================================
def ShowBias(ep):
    global biasVars
    global biasHistory
    if ep == 1: 
        biasVars = [v for v in tf.global_variables() if '/bias' in v.name]
        biasHistory = []
    biasHistory.append(VariableStates(biasVars))
    if ep == co.epochs:
        biasHistory = np.array(biasHistory).transpose()
        md.log.ShowMatrix(biasHistory, rowInfo=biasVars, view=1, title='Bias History')

#========================================
# visualize the values of 3rd layer
#========================================

def ShowLayer3(ep):
    if  ep % co.refreshFreq == 0:
       L3 = md.Eval2( 'Layer_3/MatMul', ds.X)
       md.log.ShowMatrix(L3, access='r', view=0, title='Epoch: ' + str(ep))

#========================================
# Visualize the node's fan-in weights
#========================================
def ShowWeights(ep):
    global wHistory
    global wVars
    if ep == 1:
        wHistory = []
        wVars = [ tf.reduce_sum(md.GetVariable('Layer_3/mx'), axis=0) + md.GetVariable('Layer_3/bias') ]
    wHistory.append(VariableStates(wVars))
    if ep == co.epochs:
        wHistory = np.array(wHistory).transpose()
        md.log.ShowMatrix(wHistory, view=1, rowInfo=co.job, title='Nodes Weight Sum')
    
def TestShow(ep):
    if co.logLevel > 1:
        ShowWeights(ep)
        ShowLayer3(ep)
#========================================
md.InitLogger()
biasLayer = 6
md.log.CfgHistogram(3, 'Layer %d bias'%biasLayer, netCfg[biasLayer])  
biasName = 'Layer_%d/bias'%biasLayer if biasLayer>=1 else 'Layer/bias'
biasVar = md.GetVariable(biasName)

def MonitorBias(ep):
    bias = md.sess.run(biasVar)
    md.log.ExtHistogram(3, bias, co.job)

#========================================

co.Train(md, ds, epCall=MonitorBias)