#=========================================================================
# Eval.ev.py
#=========================================================================
import sys,os,csv
os.environ['TF_CPP_MIN_LOG_LEVEL']='3'
import numpy as np
from ModelUtil import ModelBuilder

#Direction GetSelectedData

modelName = sys.argv[1]
md = ModelBuilder()
md.LoadModel(modelName)
output = []
print('Processing the test data...')
with open('testData.csv', 'r') as fin:
    reader = csv.reader(fin, delimiter="|")
    rowList = []
    for row in reader:
        rowList.append(row)
        if len(rowList) >= 50:
            output.append( md.Eval(np.array(rowList, dtype=np.float32)) )
            rowList.clear()
    if len(rowList) > 0:
        output.append( md.Eval(np.array(rowList, dtype=np.float32)) )

output = np.concatenate(output)
md.log.AppMapping2(output)