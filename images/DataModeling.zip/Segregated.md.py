#=========================================================================
# Segregated Network
#=========================================================================
from ModelUtil import *

co = CmdOptions()
ds = ModelDataset('+', 'Shp')
md = ModelBuilder(ds.xDim, ds.yDim, co.job)

md.r0 = 0.0005
md.AddLanes( [[200, 130, 20, 1]] * ds.yDim, tf.nn.sigmoid)
md.cost = tf.reduce_sum( tf.square(md.Label() - md.Output()))
co.Train(md, ds)
