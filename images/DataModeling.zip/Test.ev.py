#=========================================================================
# Test.ev.py
# Raw evaluation test script
#=========================================================================
import sys
import tensorflow as tf
import numpy as np
from ModelUtil import *

modelName = sys.argv[1]
md = ModelBuilder()
md.LoadModel(modelName)

'''
m = md.GetVariableValue('mx_2:0')
m = np.sum(m, axis=0)
md.log.ShowMatrix(m, view=1)
'''

data = np.genfromtxt('inData.csv', delimiter='|', dtype=np.float32)
msg = 'layer: 2 '
tb = md.Eval2('Layer_2/MatMul', data)
key = np.sum(tb, axis=0).argsort()
tb = np.take(tb, key, axis=1)
md.log.ShowMatrix(tb, access='n', view=1, title=msg)
#md.log.RunScript('vv.GuiManager.TileAllWindows()')
