#=========================================================================
# Script to create model that performs PCA dimensionality reduction
#=========================================================================
from ModelUtil import *
import numpy.linalg as npl

co = CmdOptions()
ds = ModelDataset('*', 'Nul')
md = ModelBuilder(ds.xDim, 0, co.job)

outDim = 5
md.InitAllVariables()

with tf.variable_scope('PCA_Layer'):
    center = np.sum(ds.X, axis=0)/ds.N
    V = ds.X - center

    if ds.X.shape[0] > ds.X.shape[1]:
        V = np.cov(V, rowvar=False)

    _, _, V = npl.svd(V)
    V = V.transpose()[:, 0:outDim]

    centerVar = tf.constant(center, name='center' )
    md.AddFilter(lambda X: X-center)
    md.top = tf.matmul(md.top, tf.constant(V, dtype=tf.float32, name='mx'))

md.Save(co.modelName)
md.log.SetStatus('Completed')

if co.logLevel >= 2:
    md.log.ShowMatrix(md.Eval(ds.X), access='n', view=0, title='PCA Dimensionality Reduction')
