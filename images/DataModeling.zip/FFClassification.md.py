#=========================================================================
# Model generator for classification.
#=========================================================================
import ModelUtil as mu

co = mu.CmdOptions()
ds = mu.ModelDataset('+', 'Clr')
md = mu.ModelBuilder(ds.xDim, ds.yDim, job=co.job)

netCfg =  2*[ds.xDim] + 2*[ds.yDim]
md.r0 = 0.0006

md.AddLayers(netCfg[0])
md.AddDropout()
md.AddLayers(netCfg[1:-1])
md.AddLayers(netCfg[-1], activation=None)

md.cost = md.SoftmaxCost(md.Output(), md.Label())
co.Train(md, ds)