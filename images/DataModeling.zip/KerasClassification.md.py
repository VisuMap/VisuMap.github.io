#=========================================================================
# Keras classification model generator
#=========================================================================
from ModelUtil import *
import os, time

from tensorflow import keras
from tensorflow.python.keras.models import Sequential
from tensorflow.python.keras.layers import Dense, Activation, Dropout
from tensorflow.python.keras import optimizers
from tensorflow.python.keras.initializers import RandomUniform
from tensorflow.python.keras import backend as K

#=========================================================================

netConfig = [300, 200, 100, 50]
learningRate = 0.0005

co = CmdOptions()
ds = ModelDataset('+', 'Clr')
log = Logger()
config = tf.ConfigProto()
config.gpu_options.allow_growth = True
sess = tf.Session(config=config)
K.set_session(sess)

#=========================================================================

def ShowPredication():
    output = md.predict(ds.X)
    try:
        md.job = co.job
        np.savetxt("predData_"+str(co.job)+".csv", output, delimiter='|', fmt='%.6f')
        log.ShowPrediction(co.job)
    except IOError as e:
        print(e)

def ShowModel():
    saver = tf.train.Saver()
    saver.save(sess, '.\\' + co.modelName, None, co.modelName+'.chk')

    if os.path.isdir('tf_log'):
        os.system('rmdir/s /q tf_log')
    writer = tf.summary.FileWriter(logdir="tf_log", graph=sess.graph)
    
    hostname = os.environ['USERDOMAIN']
    os.system('start chrome http://%s:6006'%hostname)
    os.system('start tensorboard --logdir="./tf_log" --port=6006')

class LossLogger(keras.callbacks.Callback):
    trainingTime = 0
    lastError = 0
    
    def on_train_begin(self, logs={}):
        self.trainingTime = time.time()

    def on_epoch_end(self, epoch, logs={}):
        ep = epoch + 1
        self.lastError = logs['loss']
        if ep % co.refreshFreq == 0:
            print('%d: %.5f'%(ep, self.lastError))
            log.ReportCost(ep, self.lastError, co.job)
            if co.logLevel>=3:
                ShowPredication()

    def on_train_end(self, logs={}):
        ShowPredication()
        self.trainingTime = time.time()-self.trainingTime
        print('Training completed! Training time: %.2f'%self.trainingTime)
        if co.logLevel >= 2:
            log.LogMsg('%d: Ep: %d, %s, LR: %.5g:, E:%.5g, T: %.3g; '%(
                co.job, co.epochs, netConfig, learningRate, self.lastError, self.trainingTime))
            if co.logLevel>=3: 
                log.LogTitle()

#=========================================================================

md = Sequential()
inzer = RandomUniform(minval=-0.1, maxval=0.1)
md.add(Dense(units=netConfig[0], activation='sigmoid', kernel_initializer=inzer, input_dim=ds.xDim))
md.add(Dropout(0.25))
for dim in netConfig[1:]:
    md.add(Dense(units=dim, activation='sigmoid', kernel_initializer=inzer))
md.add(Dense(units=ds.yDim, activation='softmax', kernel_initializer=inzer))

adam = optimizers.Adam(lr=learningRate, decay=0)
md.compile(loss=keras.losses.categorical_crossentropy, optimizer=adam)
md.fit(ds.X, ds.Y, epochs=co.epochs, verbose=0, callbacks=[LossLogger()], batch_size=25, shuffle=True)

if not co.modelName.startswith('<NotSave>'):
    if co.logLevel >= 10: ShowModel()
    md.save(co.modelName + '.h5')
    log.SaveModel(co.job)
