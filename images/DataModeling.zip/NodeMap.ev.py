#=========================================================================
# NodeMap.ev.py
# Raw evaluation test script
#=========================================================================
import sys, time
import tensorflow as tf
import numpy as np
from ModelUtil import *

#Direction GetSelectedData

modelName = sys.argv[1]
arg = sys.argv[2] if len(sys.argv)>2 else 'N'
def HasFlag(flag): return arg.find(flag)>=0

data = np.genfromtxt('testData.csv', delimiter='|', dtype=np.float32)
md = ModelBuilder()
md.LoadModel(modelName)
md.InitLogger()

#====================================================================

def SortRows(tb):
    od = np.sum(tb, axis=0).argsort()
    return np.take(tb, od, axis=1)

def AggregationNodes():
    mmNodes = []
    for v in  tf.get_default_graph().as_graph_def().node:
        if v.name.endswith('/mx/read'):
            mmNodes.append(v.name.replace('/mx/read', '/MatMul'))
        elif v.name.endswith('/cnn'):
            mmNodes.append(v.name)
    return mmNodes

def AllWeightMatrixes():
    wmList = []
    for v in tf.global_variables():
        if v.name.endswith('/mx:0'):
            wmList.append(v.name[0:-2])
    return wmList

#====================================================================

def ShowNodeMap(md, inData, nodes):
    tbList = [tb.transpose() for tb in md.Eval2(nodes, inData)]
    dimList = [tb.shape[0] for tb in tbList]
    tb = np.concatenate(tbList, axis=0)
    md.InitLogger()
    md.log.ShowMatrix(tb, rowInfo=dimList, view=8, title='Node Activity: '+str(np.shape(tb)))
    script = 'pp.Reset().Start().Show3DView().DoPcaCentralize();pp.GetNumberTable().ShowHeatMap().Title="Node Activities: %s";'%(str(np.shape(tb)));
    script += 'pp.Close();'
    md.log.RunScript(script)

def ShowEmbedding(md, inData, nodes):
    for k, tb in enumerate(md.Eval2(nodes, inData)):
        md.log.ShowMatrix(tb, view=8, title='Layer Embedding')
        script = 'pp.Reset().Start().Show3DView().DoPcaCentralize().Title="Layer: %s";'%(nodes[k])
        script += 'pp.Close();'
        md.log.RunScript(script)
        time.sleep(5)

def ShowWeightMatrix(md, tensorNames, viewType=0):
    varList = [ md.GetVariable(nm) for nm in tensorNames ]
    tensorList = md.sess.run(varList)
    for idx, t in enumerate(tensorList):
        md.log.ShowMatrix(t, view=0, title='Weight Matrix. Layer: ' + tensorNames[idx] + ', ' + str(np.shape(t)))

#====================================================================

# show all variable names.
if HasFlag('L'):
    print('Global variables:')
    for v in tf.global_variables():
        print(v.name, ': ', v.shape)
    print('------------------------------------------')
    print('Operation list:')
    for v in  tf.get_default_graph().as_graph_def().node:
        print(v.name, ': ', v.op)
    time.sleep(5)

# show the map of all nodes embedded according to their output vectors.
if HasFlag('N'):
    nodes = AggregationNodes()
    print(nodes)
    ShowNodeMap(md, data, nodes)

# show node matrix output tensor (before apply threadhold gatting)
if HasFlag('E'):
    nodes = AggregationNodes()
    print(nodes)
    ShowEmbedding(md, data, nodes)

# show node output tensor
if HasFlag('e'):
    nodes = AggregationNodes()
    #nodes = [ nm.replace('/MatMul', '/Relu') for nm in nodes ]
    nodes = [ nm.replace('/MatMul', '/LeakyRelu/Maximum') for nm in nodes ]
    print(nodes)
    ShowEmbedding(md, data, nodes)

# show all weight matrix
if HasFlag('W'):
    nodes = AllWeightMatrixes()
    print(nodes)
    ShowWeightMatrix(md, nodes, viewType=0)

# show all bias vectors:
if HasFlag('B'):
    for v in tf.global_variables():
        if v.name.endswith('/bias:0'):
            tb = md.GetVariableValue(v)
            md.log.ShowMatrix(tb, view=14, title='Bias Vector. Layer: ' + v.name)

# show the output vector and output weights of nodes of layer:
if HasFlag('D'):
    # md.sess.run(tf.global_variables_initializer())
    for L in range(8):
        if L == 0:
            mx = md.GetVariableValue('Layer/mx:0')
        else:
            mx = md.GetVariableValue('Layer_%d/mx:0'%L)

        if L == 0:
            ac = data
            bs = np.zeros(data.shape[1], dtype=np.float32)
        elif L == 1:
            ac = md.Eval2('Layer/LeakyRelu/Maximum', data)
            bs = md.GetVariableValue('Layer/bias')
        else:
            ac = md.Eval2('Layer_%d/LeakyRelu/Maximum'%(L-1), data)
            bs = md.GetVariableValue('Layer_%d/bias'%(L-1))

        mx = mx.transpose()
        bs = np.reshape(bs, [1, -1])

        '''
        tb = np.concatenate((mx, bs, ac))
        types = [mx.shape[0], bs.shape[0], ac.shape[0]]
        '''
        tb = ac
        types = None
        md.log.ShowMatrix(tb, rowInfo=types, title='Layer %d: node out-weight, bias and output (by column)'%L)

