#=========================================================================
# Script to re-train a saved model.
#=========================================================================
from ModelUtil import *

co = CmdOptions()
ds = ModelDataset('+', 'Mdl')
md = ModelBuilder(job=co.job)
md.LoadModel(co.modelName)

#Learning without reset learning rate.
#md.LoadModel(modelName, False)
#md.SetVar(md.GetVar('globalStep:0'), 2*md.GetVariableValue('globalStep:0'))

if ds.xDim != md.Input().shape[1]:
    print('Input dimension mismatch! %d!=%d'%(ds.xDim, md.Input().shape[1]))
    quit()
if ds.yDim != md.Label().shape[1]:
    print('Output dimension mismatch! %d!=%d'%(ds.yDim, md.Label().shape[1]))
    quit()

md.Train(ds, co.epochs, co.logLevel, co.refreshFreq)
md.Save(co.modelName)
