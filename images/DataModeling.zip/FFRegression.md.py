#=========================================================================
# Model generator for regression.
#=========================================================================
import tensorflow as tf
import ModelUtil as mu

co = mu.CmdOptions()
ds = mu.ModelDataset('+', 'Shp')
md = mu.ModelBuilder(ds.xDim, ds.yDim, job=co.job)

netCfg = 2*[ds.xDim] + [10]
md.r0 = 0.0001*(co.job+5)

md.AddLayers(netCfg[0])
md.AddDropout()   
md.AddLayers(netCfg[1:])
md.AddLayers(ds.yDim, activation=tf.nn.sigmoid)
md.cost = md.SquaredCost(md.Output(), md.Label()) 

co.Train(md, ds)

