#=========================================================================
# Using autoencoder graph to perform MDS services
#=========================================================================
import ModelUtil as mu
import tensorflow as tf

co = mu.CmdOptions()
ds = mu.ModelDataset('+', 'Nul')
md = mu.ModelBuilder(ds.xDim, ds.xDim, co.job)

ds.Y = ds.X
netCfg = [40, ds.mapDim, 80, ds.xDim]
md.r0 = 0.005

for dim in netCfg:
    md.AddLayers(dim, tf.nn.leaky_relu)
    if dim == ds.mapDim: 
        xyz = tf.identity(md.Output(), name='xyz')


# a regulator to attract the coordinates to the middle of the 3D space.
reg = 0.1 * tf.reduce_sum( tf.square(xyz - tf.fill([ds.mapDim], 0.5)) )

md.cost = md.SquaredCost(md.Output(), md.Label()) + reg
md.log.RunScript('vv.GuiManager.RememberCurrentMap();')

def UpdateMap(ep):
    if co.logLevel >= 3:
        md.log.UpdateMap2(md.Eval2(xyz, ds.X), co.job)        
        print('%d: %.6g'%(ep, md.lastError), flush=True)
        md.log.ReportCost(ep, md.lastError, md.job)
        return False
    else:
        return True

md.modelInfo.update({'Algorithm':'Autoencoder', 'netCfg':netCfg, 'mapDim':ds.mapDim})
co.Save(md)
co.Train(md, ds, UpdateMap)
