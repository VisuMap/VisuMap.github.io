#=========================================================================
# Autoencoder.ev.py
# Script to apply a trained autoencoder model.
#=========================================================================
import sys,os
os.environ['TF_CPP_MIN_LOG_LEVEL']='3'
import tensorflow as tf
import numpy as np
from ModelUtil import *

#Direction GetSelectedData

modelName = sys.argv[1]
md = ModelBuilder()
md.LoadModel(modelName)

xyzOp = tf.get_default_graph().get_operation_by_name('xyz')
test_data = np.genfromtxt('testData.csv', delimiter='|', dtype=np.float32)
xyz = md.Eval2(xyzOp, test_data)
np.savetxt("predData.csv", xyz, delimiter='|', fmt='%.6f')

md.log.RunScript('vv.GuiManager.RememberCurrentMap();')
mapType = 'Rectangle' if np.shape(xyz)[1] == 2 else 'Cube'
md.log.RunScript('vv.Map.MapType="%s";'%mapType)
md.log.UpdateMap(0)
