#=========================================================================
# Model generator for regression with target labels defined by a filter 
#=========================================================================
from ModelUtil import *

co = CmdOptions()
ds = ModelDataset('*', 'Var:RightHalf')
md = ModelBuilder(ds.xDim, ds.yDim, co.job)

netCfg = [400, 350, 300, 250, 200, 150, 100, ds.yDim]
md.r0 = 0.001

md.AddLayers(netCfg[0], tf.nn.sigmoid)
md.AddDropout()
md.AddLayers(netCfg[1:], tf.nn.sigmoid)
md.cost = md.SquaredCost(md.Output(), md.Label()) 
co.Train(md, ds)
