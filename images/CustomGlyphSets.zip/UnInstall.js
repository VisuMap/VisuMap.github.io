vv.RemoveGlyphSet("Red Green 3");
vv.RemoveGlyphSet("Phases 8");
vv.RemoveGlyphSet("Phases 16");
vv.RemoveGlyphSet("Alpha Particles");
vv.RemoveGlyphSet("ColorWheel 128");
vv.RemovePlugin("Custom Glyphs");
