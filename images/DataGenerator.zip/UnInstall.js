vv.RemovePlugin("Data Generator");
