var dir = vv.CurrentScriptPath.substr(0, vv.CurrentScriptPath.lastIndexOf("\\") + 1);
vv.InstallPlugin("Data Generator", dir +"DataGenerator.dll", true);
