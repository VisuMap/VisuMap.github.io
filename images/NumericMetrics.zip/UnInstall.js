vv.RemovePlugin("Numeric Metrics");
