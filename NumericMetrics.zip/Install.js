var dir = vv.CurrentScriptPath.substr(0, vv.CurrentScriptPath.lastIndexOf("\\") + 1);
vv.InstallPlugin("Numeric Metrics", dir +"NumericMetrics.dll", true);
